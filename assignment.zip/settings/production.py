"""
Settings for the production server.
"""
from .base import *

DEBUG = False
