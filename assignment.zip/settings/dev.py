"""
Settings for the development server.
"""
from .base import *
