"""
This app contains resources, endpoints and models for shortening urls.
"""
