"""
Constants for use in the assignment.
"""
ADMIN_GROUP_NAME = 'admin'
